A Pen created at CodePen.io. You can find this one at http://codepen.io/nikhil8krishnan/pen/gaybLK.

 Responsive Material design form using by jQuery and sass.